package sungil.mysmrecycler2

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Disc(
	var title: String,
	var info: String,
	var imgUrl: String
) : Parcelable
