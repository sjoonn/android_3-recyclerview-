package sungil.mysmrecycler2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DiscActivity : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_disc)
	}
}