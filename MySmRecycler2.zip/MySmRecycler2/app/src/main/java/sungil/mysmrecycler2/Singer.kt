package sungil.mysmrecycler2

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Singer(
	var name: String,
	var info: String,
	var imgUrl: String,
	var discList: List<Disc>
) : Parcelable