package sungil.mysmrecycler2

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import sungil.mysmrecycler2.databinding.RvItemDiscBinding

class DiscAdapter(val discList: List<Disc>) :
	RecyclerView.Adapter<DiscAdapter.ViewHolder>() {
	inner class ViewHolder(
		val binding: RvItemDiscBinding
	) : RecyclerView.ViewHolder(binding.root) {
		fun bind(disc: Disc) { // XML 과 data class 를 직접 연결해줌
			Glide.with(binding.ivCover.context)
				.load(disc.imgUrl)
				.into(binding.ivCover)
			binding.tvTitle.text = disc.title
			binding.tvInfo.text = disc.info
		}
	}

	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
		return ViewHolder(
			RvItemDiscBinding.inflate(
				LayoutInflater.from(parent.context), parent, false
			)
		)
	}

	override fun onBindViewHolder(holder: ViewHolder, position: Int) {
		val friend = discList[position]
		holder.bind(friend)
	}

	override fun getItemCount(): Int {
		return discList.size
	}
}