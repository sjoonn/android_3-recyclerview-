package sungil.mysmrecycler2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import sungil.mysmrecycler2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
	private lateinit var binding: ActivityMainBinding
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		binding = ActivityMainBinding.inflate(layoutInflater)
		setContentView(binding.root)

		val adapter = SingerAdapter(singerList)
		binding.rvSinger.adapter = adapter
	}

	companion object {
		val singerList = listOf<Singer>(
			Singer(
				"보아",
				"11월 5일",
				"https://smtown-cdn.smtown.com/upload/profile/web-detail/37a110897bd843efab45acdacf99d6dd_2022-02-17-05-13-03.jpg",
				listOf<Disc>(
					Disc(
						"ID ; Peace B",
						"2000/08/25",
						"https://smtown-cdn.smtown.com/upload/old-data/old/album/images/000/000/001/1.jpg"
					),
					Disc(
						"Don't Start Now-Jumping Into The World",
						"2001/03/05",
						"https://smtown-cdn.smtown.com/upload/old-data/old/album/images/000/000/002/2.jpg"
					),
					Disc(
						"SM Best Album 2",
						"2001/05/01",
						"https://smtown-cdn.smtown.com/upload/old-data/old/album/images/000/000/475/475.jpg"
					),
					Disc(
						"No.1",
						"2002/04/01",
						"https://smtown-cdn.smtown.com/upload/old-data/old/album/images/000/000/009/9.jpg"
					),
					Disc(
						"Miracle",
						"2002/09/24",
						"https://smtown-cdn.smtown.com/upload/old-data/old/album/images/000/000/016/16.jpg"
					)
				)
			),
			Singer(
				"소녀시대",
				"2007년 8월 5일 데뷔",
				"https://smtown-cdn.smtown.com/upload/profile/web-detail/385cb983398d4fe392bf8aba5ca39302_2022-02-18-10-08-32.jpg",
				listOf<Disc>(
					Disc(
						"다시 만난 세계",
						"2007/08/03",
						"https://smtown-cdn.smtown.com/upload/old-data/old/album/images/000/000/070/70.jpg"
					),
					Disc(
						"소녀시대",
						"2007/11/01",
						"https://smtown-cdn.smtown.com/upload/old-data/old/album/images/000/000/071/71.jpg"
					)
				)
			)
		)
	}
}