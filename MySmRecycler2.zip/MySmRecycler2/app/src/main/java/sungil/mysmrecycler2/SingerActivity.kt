package sungil.mysmrecycler2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.bumptech.glide.Glide
import sungil.mysmrecycler2.databinding.ActivitySingerBinding

class SingerActivity : AppCompatActivity() {
	private lateinit var binding: ActivitySingerBinding
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		binding = ActivitySingerBinding.inflate(layoutInflater)
		setContentView(binding.root)

		val singer = intent.getParcelableExtra<Singer>("singerObj")
		Glide.with(this)
			.load(singer?.imgUrl)
			.into(binding.ivProfile)
		binding.tvName.text = singer?.name
		binding.tvInfo.text = singer?.info
	}
}